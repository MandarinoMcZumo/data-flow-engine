from loguru import logger
from confluent_kafka.admin import AdminClient, NewTopic


class KafkaAgent:
    def __init__(self, bootstrap_servers: str):
        self._client = AdminClient({'bootstrap.servers': bootstrap_servers})

    def add_topic(self, topic: str) -> None:
        new_topic = NewTopic(topic)
        fs = self._client.create_topics(new_topics=[new_topic])
        for topic, f in fs.items():
            try:
                f.result()
                logger.info("Topic {} created".format(topic))
            except Exception as e:
                logger.warning("Failed to create topic {}: {}".format(topic, e))
